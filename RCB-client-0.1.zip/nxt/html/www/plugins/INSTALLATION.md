----
# PLUGIN INSTALLATION #

----
# Installation #

1. Download the plugin from a trusted source
2. Extract the plugin in the ``plugins`` folder of your client
3. Run the NRS client
4. Plugin status info can be found on the plugin settings page

----
# SECURITY #

PLEASE MAKE SURE TO READ THE NOTES ON SECURITY IN THE 
``SECURITY_WARNING.md`` FILE IN THE ``plugins`` FOLDER
BEFORE YOU LOG INTO YOUR CLIENT HAVING ANY PLUGINS INSTALLED!